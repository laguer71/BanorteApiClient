﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Banorte.Adquiriente.Api
{
   public partial class VerificarTarjetahabienteControl : UserControl
   {
      public VerificarTarjetahabienteControl()
      {
         InitializeComponent();
      }
   }
}
