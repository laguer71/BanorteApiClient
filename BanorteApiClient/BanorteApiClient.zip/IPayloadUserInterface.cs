﻿namespace Banorte.Adquiriente.Api
{
   public interface IPayloadUserInterface
   {
      string Payload();
      string Endpoint();
   }
}
