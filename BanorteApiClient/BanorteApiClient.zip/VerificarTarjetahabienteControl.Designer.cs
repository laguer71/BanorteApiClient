﻿namespace Banorte.Adquiriente.Api
{
   partial class VerificarTarjetahabienteControl
   {
      /// <summary> 
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary> 
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Component Designer generated code

      /// <summary> 
      /// Required method for Designer support - do not modify 
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.labelnumeroCuenta = new System.Windows.Forms.Label();
         this.labelmarcaTarjeta = new System.Windows.Forms.Label();
         this.labelmesExpiracionTarjeta = new System.Windows.Forms.Label();
         this.labelanioExpiracionTarjeta = new System.Windows.Forms.Label();
         this.labelcomentarios = new System.Windows.Forms.Label();
         this.labelidAfiliacion = new System.Windows.Forms.Label();
         this.labelcodigoRefAfiliacion = new System.Windows.Forms.Label();
         this.labeltipoDivisa = new System.Windows.Forms.Label();
         this.labelmontoCompra = new System.Windows.Forms.Label();
         this.labelidDispositivoDactilar = new System.Windows.Forms.Label();
         this.labelnombrePersona = new System.Windows.Forms.Label();
         this.labelclaveUsuario = new System.Windows.Forms.Label();
         this.labelnumeroComercio = new System.Windows.Forms.Label();
         this.labelidTerminal = new System.Windows.Forms.Label();
         this.labelnumeroOrden = new System.Windows.Forms.Label();
         this.labelmodoVenta = new System.Windows.Forms.Label();
         this.labelrevisor = new System.Windows.Forms.Label();
         this.textnumeroCuenta = new System.Windows.Forms.TextBox();
         this.textmarcaTarjeta = new System.Windows.Forms.TextBox();
         this.textmesExpiracionTarjeta = new System.Windows.Forms.TextBox();
         this.textanioExpiracionTarjeta = new System.Windows.Forms.TextBox();
         this.textcomentarios = new System.Windows.Forms.TextBox();
         this.textidAfiliacion = new System.Windows.Forms.TextBox();
         this.textcodigoRefAfiliacion = new System.Windows.Forms.TextBox();
         this.texttipoDivisa = new System.Windows.Forms.TextBox();
         this.textmontoCompra = new System.Windows.Forms.TextBox();
         this.textidDispositivoDactilar = new System.Windows.Forms.TextBox();
         this.textnombrePersona = new System.Windows.Forms.TextBox();
         this.textclaveUsuario = new System.Windows.Forms.TextBox();
         this.textnumeroComercio = new System.Windows.Forms.TextBox();
         this.textidTerminal = new System.Windows.Forms.TextBox();
         this.textnumeroOrden = new System.Windows.Forms.TextBox();
         this.textmodoVenta = new System.Windows.Forms.TextBox();
         this.textrevisor = new System.Windows.Forms.TextBox();
         this.layoutVerificarTarjetahabiente = new System.Windows.Forms.TableLayoutPanel();
         this.labeltipoDeOperacion = new System.Windows.Forms.Label();
         this.layoutVerificarTarjetahabiente.SuspendLayout();
         this.SuspendLayout();
         // 
         // labelnumeroCuenta
         // 
         this.labelnumeroCuenta.Dock = System.Windows.Forms.DockStyle.Fill;
         this.labelnumeroCuenta.Location = new System.Drawing.Point(3, 20);
         this.labelnumeroCuenta.Name = "labelnumeroCuenta";
         this.labelnumeroCuenta.Size = new System.Drawing.Size(239, 26);
         this.labelnumeroCuenta.TabIndex = 0;
         this.labelnumeroCuenta.Text = "numeroCuenta:";
         // 
         // labelmarcaTarjeta
         // 
         this.labelmarcaTarjeta.Dock = System.Windows.Forms.DockStyle.Fill;
         this.labelmarcaTarjeta.Location = new System.Drawing.Point(3, 46);
         this.labelmarcaTarjeta.Name = "labelmarcaTarjeta";
         this.labelmarcaTarjeta.Size = new System.Drawing.Size(239, 26);
         this.labelmarcaTarjeta.TabIndex = 0;
         this.labelmarcaTarjeta.Text = "marcaTarjeta:";
         // 
         // labelmesExpiracionTarjeta
         // 
         this.labelmesExpiracionTarjeta.Dock = System.Windows.Forms.DockStyle.Fill;
         this.labelmesExpiracionTarjeta.Location = new System.Drawing.Point(3, 72);
         this.labelmesExpiracionTarjeta.Name = "labelmesExpiracionTarjeta";
         this.labelmesExpiracionTarjeta.Size = new System.Drawing.Size(239, 26);
         this.labelmesExpiracionTarjeta.TabIndex = 0;
         this.labelmesExpiracionTarjeta.Text = "mesExpiracionTarjeta:";
         // 
         // labelanioExpiracionTarjeta
         // 
         this.labelanioExpiracionTarjeta.Dock = System.Windows.Forms.DockStyle.Fill;
         this.labelanioExpiracionTarjeta.Location = new System.Drawing.Point(3, 98);
         this.labelanioExpiracionTarjeta.Name = "labelanioExpiracionTarjeta";
         this.labelanioExpiracionTarjeta.Size = new System.Drawing.Size(239, 26);
         this.labelanioExpiracionTarjeta.TabIndex = 0;
         this.labelanioExpiracionTarjeta.Text = "anioExpiracionTarjeta:";
         // 
         // labelcomentarios
         // 
         this.labelcomentarios.Dock = System.Windows.Forms.DockStyle.Fill;
         this.labelcomentarios.Location = new System.Drawing.Point(3, 124);
         this.labelcomentarios.Name = "labelcomentarios";
         this.labelcomentarios.Size = new System.Drawing.Size(239, 26);
         this.labelcomentarios.TabIndex = 0;
         this.labelcomentarios.Text = "comentarios:";
         // 
         // labelidAfiliacion
         // 
         this.labelidAfiliacion.Dock = System.Windows.Forms.DockStyle.Fill;
         this.labelidAfiliacion.Location = new System.Drawing.Point(3, 150);
         this.labelidAfiliacion.Name = "labelidAfiliacion";
         this.labelidAfiliacion.Size = new System.Drawing.Size(239, 26);
         this.labelidAfiliacion.TabIndex = 0;
         this.labelidAfiliacion.Text = "comentarios:";
         // 
         // labelcodigoRefAfiliacion
         // 
         this.labelcodigoRefAfiliacion.Dock = System.Windows.Forms.DockStyle.Fill;
         this.labelcodigoRefAfiliacion.Location = new System.Drawing.Point(3, 176);
         this.labelcodigoRefAfiliacion.Name = "labelcodigoRefAfiliacion";
         this.labelcodigoRefAfiliacion.Size = new System.Drawing.Size(239, 26);
         this.labelcodigoRefAfiliacion.TabIndex = 0;
         this.labelcodigoRefAfiliacion.Text = "codigoRefAfiliacion:";
         // 
         // labeltipoDivisa
         // 
         this.labeltipoDivisa.Dock = System.Windows.Forms.DockStyle.Fill;
         this.labeltipoDivisa.Location = new System.Drawing.Point(3, 202);
         this.labeltipoDivisa.Name = "labeltipoDivisa";
         this.labeltipoDivisa.Size = new System.Drawing.Size(239, 26);
         this.labeltipoDivisa.TabIndex = 0;
         this.labeltipoDivisa.Text = "tipoDivisa:";
         // 
         // labelmontoCompra
         // 
         this.labelmontoCompra.Dock = System.Windows.Forms.DockStyle.Fill;
         this.labelmontoCompra.Location = new System.Drawing.Point(3, 228);
         this.labelmontoCompra.Name = "labelmontoCompra";
         this.labelmontoCompra.Size = new System.Drawing.Size(239, 26);
         this.labelmontoCompra.TabIndex = 0;
         this.labelmontoCompra.Text = "montoCompra:";
         // 
         // labelidDispositivoDactilar
         // 
         this.labelidDispositivoDactilar.Dock = System.Windows.Forms.DockStyle.Fill;
         this.labelidDispositivoDactilar.Location = new System.Drawing.Point(3, 254);
         this.labelidDispositivoDactilar.Name = "labelidDispositivoDactilar";
         this.labelidDispositivoDactilar.Size = new System.Drawing.Size(239, 26);
         this.labelidDispositivoDactilar.TabIndex = 0;
         this.labelidDispositivoDactilar.Text = "idDispositivoDactilar:";
         // 
         // labelnombrePersona
         // 
         this.labelnombrePersona.Dock = System.Windows.Forms.DockStyle.Fill;
         this.labelnombrePersona.Location = new System.Drawing.Point(3, 280);
         this.labelnombrePersona.Name = "labelnombrePersona";
         this.labelnombrePersona.Size = new System.Drawing.Size(239, 26);
         this.labelnombrePersona.TabIndex = 0;
         this.labelnombrePersona.Text = "nombrePersona:";
         // 
         // labelclaveUsuario
         // 
         this.labelclaveUsuario.Dock = System.Windows.Forms.DockStyle.Fill;
         this.labelclaveUsuario.Location = new System.Drawing.Point(3, 306);
         this.labelclaveUsuario.Name = "labelclaveUsuario";
         this.labelclaveUsuario.Size = new System.Drawing.Size(239, 26);
         this.labelclaveUsuario.TabIndex = 0;
         this.labelclaveUsuario.Text = "claveUsuario:";
         // 
         // labelnumeroComercio
         // 
         this.labelnumeroComercio.Dock = System.Windows.Forms.DockStyle.Fill;
         this.labelnumeroComercio.Location = new System.Drawing.Point(3, 332);
         this.labelnumeroComercio.Name = "labelnumeroComercio";
         this.labelnumeroComercio.Size = new System.Drawing.Size(239, 26);
         this.labelnumeroComercio.TabIndex = 0;
         this.labelnumeroComercio.Text = "numeroComercio:";
         // 
         // labelidTerminal
         // 
         this.labelidTerminal.Dock = System.Windows.Forms.DockStyle.Fill;
         this.labelidTerminal.Location = new System.Drawing.Point(3, 358);
         this.labelidTerminal.Name = "labelidTerminal";
         this.labelidTerminal.Size = new System.Drawing.Size(239, 26);
         this.labelidTerminal.TabIndex = 0;
         this.labelidTerminal.Text = ":idTerminal";
         // 
         // labelnumeroOrden
         // 
         this.labelnumeroOrden.Dock = System.Windows.Forms.DockStyle.Fill;
         this.labelnumeroOrden.Location = new System.Drawing.Point(3, 384);
         this.labelnumeroOrden.Name = "labelnumeroOrden";
         this.labelnumeroOrden.Size = new System.Drawing.Size(239, 26);
         this.labelnumeroOrden.TabIndex = 0;
         this.labelnumeroOrden.Text = "numeroOrden:";
         // 
         // labelmodoVenta
         // 
         this.labelmodoVenta.Dock = System.Windows.Forms.DockStyle.Fill;
         this.labelmodoVenta.Location = new System.Drawing.Point(3, 410);
         this.labelmodoVenta.Name = "labelmodoVenta";
         this.labelmodoVenta.Size = new System.Drawing.Size(239, 26);
         this.labelmodoVenta.TabIndex = 0;
         this.labelmodoVenta.Text = "modoVenta:";
         // 
         // labelrevisor
         // 
         this.labelrevisor.Dock = System.Windows.Forms.DockStyle.Fill;
         this.labelrevisor.Location = new System.Drawing.Point(3, 436);
         this.labelrevisor.Name = "labelrevisor";
         this.labelrevisor.Size = new System.Drawing.Size(239, 32);
         this.labelrevisor.TabIndex = 0;
         this.labelrevisor.Text = "revisor";
         // 
         // textnumeroCuenta
         // 
         this.textnumeroCuenta.Dock = System.Windows.Forms.DockStyle.Fill;
         this.textnumeroCuenta.Location = new System.Drawing.Point(248, 23);
         this.textnumeroCuenta.Name = "textnumeroCuenta";
         this.textnumeroCuenta.Size = new System.Drawing.Size(239, 20);
         this.textnumeroCuenta.TabIndex = 1;
         // 
         // textmarcaTarjeta
         // 
         this.textmarcaTarjeta.Dock = System.Windows.Forms.DockStyle.Fill;
         this.textmarcaTarjeta.Location = new System.Drawing.Point(248, 49);
         this.textmarcaTarjeta.Name = "textmarcaTarjeta";
         this.textmarcaTarjeta.Size = new System.Drawing.Size(239, 20);
         this.textmarcaTarjeta.TabIndex = 0;
         // 
         // textmesExpiracionTarjeta
         // 
         this.textmesExpiracionTarjeta.Dock = System.Windows.Forms.DockStyle.Fill;
         this.textmesExpiracionTarjeta.Location = new System.Drawing.Point(248, 75);
         this.textmesExpiracionTarjeta.Name = "textmesExpiracionTarjeta";
         this.textmesExpiracionTarjeta.Size = new System.Drawing.Size(239, 20);
         this.textmesExpiracionTarjeta.TabIndex = 0;
         // 
         // textanioExpiracionTarjeta
         // 
         this.textanioExpiracionTarjeta.Dock = System.Windows.Forms.DockStyle.Fill;
         this.textanioExpiracionTarjeta.Location = new System.Drawing.Point(248, 101);
         this.textanioExpiracionTarjeta.Name = "textanioExpiracionTarjeta";
         this.textanioExpiracionTarjeta.Size = new System.Drawing.Size(239, 20);
         this.textanioExpiracionTarjeta.TabIndex = 0;
         // 
         // textcomentarios
         // 
         this.textcomentarios.Dock = System.Windows.Forms.DockStyle.Fill;
         this.textcomentarios.Location = new System.Drawing.Point(248, 127);
         this.textcomentarios.Name = "textcomentarios";
         this.textcomentarios.Size = new System.Drawing.Size(239, 20);
         this.textcomentarios.TabIndex = 0;
         // 
         // textidAfiliacion
         // 
         this.textidAfiliacion.Dock = System.Windows.Forms.DockStyle.Fill;
         this.textidAfiliacion.Location = new System.Drawing.Point(248, 153);
         this.textidAfiliacion.Name = "textidAfiliacion";
         this.textidAfiliacion.Size = new System.Drawing.Size(239, 20);
         this.textidAfiliacion.TabIndex = 0;
         // 
         // textcodigoRefAfiliacion
         // 
         this.textcodigoRefAfiliacion.Dock = System.Windows.Forms.DockStyle.Fill;
         this.textcodigoRefAfiliacion.Location = new System.Drawing.Point(248, 179);
         this.textcodigoRefAfiliacion.Name = "textcodigoRefAfiliacion";
         this.textcodigoRefAfiliacion.Size = new System.Drawing.Size(239, 20);
         this.textcodigoRefAfiliacion.TabIndex = 0;
         // 
         // texttipoDivisa
         // 
         this.texttipoDivisa.Dock = System.Windows.Forms.DockStyle.Fill;
         this.texttipoDivisa.Location = new System.Drawing.Point(248, 205);
         this.texttipoDivisa.Name = "texttipoDivisa";
         this.texttipoDivisa.Size = new System.Drawing.Size(239, 20);
         this.texttipoDivisa.TabIndex = 0;
         // 
         // textmontoCompra
         // 
         this.textmontoCompra.Dock = System.Windows.Forms.DockStyle.Fill;
         this.textmontoCompra.Location = new System.Drawing.Point(248, 231);
         this.textmontoCompra.Name = "textmontoCompra";
         this.textmontoCompra.Size = new System.Drawing.Size(239, 20);
         this.textmontoCompra.TabIndex = 0;
         // 
         // textidDispositivoDactilar
         // 
         this.textidDispositivoDactilar.Dock = System.Windows.Forms.DockStyle.Fill;
         this.textidDispositivoDactilar.Location = new System.Drawing.Point(248, 257);
         this.textidDispositivoDactilar.Name = "textidDispositivoDactilar";
         this.textidDispositivoDactilar.Size = new System.Drawing.Size(239, 20);
         this.textidDispositivoDactilar.TabIndex = 0;
         // 
         // textnombrePersona
         // 
         this.textnombrePersona.Dock = System.Windows.Forms.DockStyle.Fill;
         this.textnombrePersona.Location = new System.Drawing.Point(248, 283);
         this.textnombrePersona.Name = "textnombrePersona";
         this.textnombrePersona.Size = new System.Drawing.Size(239, 20);
         this.textnombrePersona.TabIndex = 0;
         // 
         // textclaveUsuario
         // 
         this.textclaveUsuario.Dock = System.Windows.Forms.DockStyle.Fill;
         this.textclaveUsuario.Location = new System.Drawing.Point(248, 309);
         this.textclaveUsuario.Name = "textclaveUsuario";
         this.textclaveUsuario.Size = new System.Drawing.Size(239, 20);
         this.textclaveUsuario.TabIndex = 0;
         // 
         // textnumeroComercio
         // 
         this.textnumeroComercio.Dock = System.Windows.Forms.DockStyle.Fill;
         this.textnumeroComercio.Location = new System.Drawing.Point(248, 335);
         this.textnumeroComercio.Name = "textnumeroComercio";
         this.textnumeroComercio.Size = new System.Drawing.Size(239, 20);
         this.textnumeroComercio.TabIndex = 0;
         // 
         // textidTerminal
         // 
         this.textidTerminal.Dock = System.Windows.Forms.DockStyle.Fill;
         this.textidTerminal.Location = new System.Drawing.Point(248, 361);
         this.textidTerminal.Name = "textidTerminal";
         this.textidTerminal.Size = new System.Drawing.Size(239, 20);
         this.textidTerminal.TabIndex = 0;
         // 
         // textnumeroOrden
         // 
         this.textnumeroOrden.Dock = System.Windows.Forms.DockStyle.Fill;
         this.textnumeroOrden.Location = new System.Drawing.Point(248, 387);
         this.textnumeroOrden.Name = "textnumeroOrden";
         this.textnumeroOrden.Size = new System.Drawing.Size(239, 20);
         this.textnumeroOrden.TabIndex = 0;
         // 
         // textmodoVenta
         // 
         this.textmodoVenta.Dock = System.Windows.Forms.DockStyle.Fill;
         this.textmodoVenta.Location = new System.Drawing.Point(248, 413);
         this.textmodoVenta.Name = "textmodoVenta";
         this.textmodoVenta.Size = new System.Drawing.Size(239, 20);
         this.textmodoVenta.TabIndex = 0;
         // 
         // textrevisor
         // 
         this.textrevisor.Dock = System.Windows.Forms.DockStyle.Fill;
         this.textrevisor.Location = new System.Drawing.Point(248, 439);
         this.textrevisor.Name = "textrevisor";
         this.textrevisor.Size = new System.Drawing.Size(239, 20);
         this.textrevisor.TabIndex = 0;
         // 
         // layoutVerificarTarjetahabiente
         // 
         this.layoutVerificarTarjetahabiente.ColumnCount = 2;
         this.layoutVerificarTarjetahabiente.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
         this.layoutVerificarTarjetahabiente.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
         this.layoutVerificarTarjetahabiente.Controls.Add(this.labelnumeroCuenta, 0, 1);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.textnumeroCuenta, 1, 1);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.labelmarcaTarjeta, 0, 2);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.textmarcaTarjeta, 1, 2);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.labelmesExpiracionTarjeta, 0, 3);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.textmesExpiracionTarjeta, 1, 3);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.labelanioExpiracionTarjeta, 0, 4);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.textanioExpiracionTarjeta, 1, 4);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.labelcomentarios, 0, 5);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.textcomentarios, 1, 5);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.labelidAfiliacion, 0, 6);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.textidAfiliacion, 1, 6);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.labelcodigoRefAfiliacion, 0, 7);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.textcodigoRefAfiliacion, 1, 7);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.labeltipoDivisa, 0, 8);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.texttipoDivisa, 1, 8);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.labelmontoCompra, 0, 9);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.textmontoCompra, 1, 9);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.labelidDispositivoDactilar, 0, 10);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.textidDispositivoDactilar, 1, 10);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.labelnombrePersona, 0, 11);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.textnombrePersona, 1, 11);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.labelclaveUsuario, 0, 12);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.textclaveUsuario, 1, 12);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.labelnumeroComercio, 0, 13);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.textnumeroComercio, 1, 13);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.labelidTerminal, 0, 14);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.textidTerminal, 1, 14);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.labelnumeroOrden, 0, 15);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.textnumeroOrden, 1, 15);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.labelmodoVenta, 0, 16);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.textmodoVenta, 1, 16);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.labelrevisor, 0, 17);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.textrevisor, 1, 17);
         this.layoutVerificarTarjetahabiente.Controls.Add(this.labeltipoDeOperacion, 0, 0);
         this.layoutVerificarTarjetahabiente.Dock = System.Windows.Forms.DockStyle.Fill;
         this.layoutVerificarTarjetahabiente.Location = new System.Drawing.Point(0, 0);
         this.layoutVerificarTarjetahabiente.Name = "layoutVerificarTarjetahabiente";
         this.layoutVerificarTarjetahabiente.RowCount = 18;
         this.layoutVerificarTarjetahabiente.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
         this.layoutVerificarTarjetahabiente.RowStyles.Add(new System.Windows.Forms.RowStyle());
         this.layoutVerificarTarjetahabiente.RowStyles.Add(new System.Windows.Forms.RowStyle());
         this.layoutVerificarTarjetahabiente.RowStyles.Add(new System.Windows.Forms.RowStyle());
         this.layoutVerificarTarjetahabiente.RowStyles.Add(new System.Windows.Forms.RowStyle());
         this.layoutVerificarTarjetahabiente.RowStyles.Add(new System.Windows.Forms.RowStyle());
         this.layoutVerificarTarjetahabiente.RowStyles.Add(new System.Windows.Forms.RowStyle());
         this.layoutVerificarTarjetahabiente.RowStyles.Add(new System.Windows.Forms.RowStyle());
         this.layoutVerificarTarjetahabiente.RowStyles.Add(new System.Windows.Forms.RowStyle());
         this.layoutVerificarTarjetahabiente.RowStyles.Add(new System.Windows.Forms.RowStyle());
         this.layoutVerificarTarjetahabiente.RowStyles.Add(new System.Windows.Forms.RowStyle());
         this.layoutVerificarTarjetahabiente.RowStyles.Add(new System.Windows.Forms.RowStyle());
         this.layoutVerificarTarjetahabiente.RowStyles.Add(new System.Windows.Forms.RowStyle());
         this.layoutVerificarTarjetahabiente.RowStyles.Add(new System.Windows.Forms.RowStyle());
         this.layoutVerificarTarjetahabiente.RowStyles.Add(new System.Windows.Forms.RowStyle());
         this.layoutVerificarTarjetahabiente.RowStyles.Add(new System.Windows.Forms.RowStyle());
         this.layoutVerificarTarjetahabiente.RowStyles.Add(new System.Windows.Forms.RowStyle());
         this.layoutVerificarTarjetahabiente.RowStyles.Add(new System.Windows.Forms.RowStyle());
         this.layoutVerificarTarjetahabiente.RowStyles.Add(new System.Windows.Forms.RowStyle());
         this.layoutVerificarTarjetahabiente.Size = new System.Drawing.Size(390, 468);
         this.layoutVerificarTarjetahabiente.TabIndex = 0;
         // 
         // labeltipoDeOperacion
         // 
         this.labeltipoDeOperacion.AutoSize = true;
         this.layoutVerificarTarjetahabiente.SetColumnSpan(this.labeltipoDeOperacion, 2);
         this.labeltipoDeOperacion.Dock = System.Windows.Forms.DockStyle.Fill;
         this.labeltipoDeOperacion.Location = new System.Drawing.Point(3, 0);
         this.labeltipoDeOperacion.Name = "labeltipoDeOperacion";
         this.labeltipoDeOperacion.Size = new System.Drawing.Size(484, 20);
         this.labeltipoDeOperacion.TabIndex = 2;
         this.labeltipoDeOperacion.Text = "tipoDeOperacion: verificar-tarjeta-habiente";
         this.labeltipoDeOperacion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
         // 
         // VerificarTarjetahabienteControl
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.AutoScroll = true;
         this.AutoScrollMinSize = new System.Drawing.Size(390, 468);
         this.Controls.Add(this.layoutVerificarTarjetahabiente);
         this.Name = "VerificarTarjetahabienteControl";
         this.Size = new System.Drawing.Size(390, 468);
         this.layoutVerificarTarjetahabiente.ResumeLayout(false);
         this.layoutVerificarTarjetahabiente.PerformLayout();
         this.ResumeLayout(false);

      }

      #endregion

      private System.Windows.Forms.TableLayoutPanel layoutVerificarTarjetahabiente;
      private System.Windows.Forms.Label labelnumeroCuenta;
      private System.Windows.Forms.Label labelmarcaTarjeta;
      private System.Windows.Forms.Label labelmesExpiracionTarjeta;
      private System.Windows.Forms.Label labelanioExpiracionTarjeta;
      private System.Windows.Forms.Label labelcomentarios;
      private System.Windows.Forms.Label labelidAfiliacion;
      private System.Windows.Forms.Label labelcodigoRefAfiliacion;
      private System.Windows.Forms.Label labeltipoDivisa;
      private System.Windows.Forms.Label labelmontoCompra;
      private System.Windows.Forms.Label labelidDispositivoDactilar;
      private System.Windows.Forms.Label labelnombrePersona;
      private System.Windows.Forms.Label labelclaveUsuario;
      private System.Windows.Forms.Label labelnumeroComercio;
      private System.Windows.Forms.Label labelidTerminal;
      private System.Windows.Forms.Label labelnumeroOrden;
      private System.Windows.Forms.Label labelmodoVenta;
      private System.Windows.Forms.Label labelrevisor;
      private System.Windows.Forms.TextBox textnumeroCuenta;
      private System.Windows.Forms.TextBox textmarcaTarjeta;
      private System.Windows.Forms.TextBox textmesExpiracionTarjeta;
      private System.Windows.Forms.TextBox textanioExpiracionTarjeta;
      private System.Windows.Forms.TextBox textcomentarios;
      private System.Windows.Forms.TextBox textidAfiliacion;
      private System.Windows.Forms.TextBox textcodigoRefAfiliacion;
      private System.Windows.Forms.TextBox texttipoDivisa;
      private System.Windows.Forms.TextBox textmontoCompra;
      private System.Windows.Forms.TextBox textidDispositivoDactilar;
      private System.Windows.Forms.TextBox textnombrePersona;
      private System.Windows.Forms.TextBox textclaveUsuario;
      private System.Windows.Forms.TextBox textnumeroComercio;
      private System.Windows.Forms.TextBox textidTerminal;
      private System.Windows.Forms.TextBox textnumeroOrden;
      private System.Windows.Forms.TextBox textmodoVenta;
      private System.Windows.Forms.TextBox textrevisor;
      private System.Windows.Forms.Label labeltipoDeOperacion;
   }
}
